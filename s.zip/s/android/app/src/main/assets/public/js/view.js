document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const postId = urlParams.get('post_id');
    let currentPage = 1;
    let isLoading = false;
    let hasMoreComments = true;
    const userId = getUserIdFromLocalStorage();
    
    fetchPost();
    fetchComments();
    setupCommentForm();

    window.addEventListener('scroll', handleScroll);

    function getUserIdFromLocalStorage() {
        const userId = localStorage.getItem('user_id');
        return userId ? Number(userId) : null;
    }

    function fetchPost() {
    fetch(`https://chati.com.ng/i/api/view.php?action=get_post&post_id=${postId}`, {
        headers: {
            'Authorization': `Bearer ${userId}`
        }
    })
    .then(response => {
        document.getElementById('spinner').style.display = 'none';

        if (!response.ok) {
            Swal.fire({
                icon: 'error',
                title: 'Post Not Found',
                text: 'This post doesn\'t exist.',
                confirmButtonText: 'Go Back'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.history.back();
                }
            });
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
            return response.json();
        } else {
            throw new Error("Oops, we haven't got JSON!");
        }
    })
    .then(post => {
        document.getElementById('post-content').innerHTML = renderPost(post);
        setupLikeButton(post.id, 'post', post.likes, post.user_liked);
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('post-content').innerHTML = '<p>Error loading post. Please try again later.</p>';
    });
}
    function fetchComments() {
        if (isLoading || !hasMoreComments) return;
        isLoading = true;
        

        fetch(`https://chati.com.ng/i/api/view.php?action=get_comments&post_id=${postId}&page=${currentPage}`, {
            headers: {
                'Authorization': `Bearer ${userId}`
            }
        })
        .then(response => response.json())
        .then(comments => {
            if (comments.length === 0) {
                hasMoreComments = false;
            } else {
                comments.forEach(comment => {
                    document.getElementById('comments-container').appendChild(renderComment(comment));
                });
                currentPage++;
            }
            isLoading = false;
            
        })
        .catch(error => {
            console.error('Error:', error);
            isLoading = false;
            
        });
    }
    function handleScroll() {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 500) {
            fetchComments();
        }
    }
let globalPostCounter = 0;

function renderPost(post) {
    // Initialize the HTML content for a single post
    let postHTML = `
        <div class="box"><br>
            <div class="post-admin"><br>
                <img src="https://chati.com.ng/i/image/${post.admin_image}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link" onclick="navigateToProfile('${post.admin_name}')">${post.admin_name}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div><br>
            <div class="post-content" id="pco">${post.content}</div>
            ${post.image && post.image !== 'null.jpg' ? 
                `<img src="https://chati.com.ng/i/uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                <br>` : ''
            }
            <div class="icons" id="icoo">
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <div onclick="reportPost(${post.id})"><i class="fas fa-flag"></i></div>     
                <button type="button" class="like-btn ${post.user_liked ? 'liked' : ''}" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="${post.user_liked ? 'color:var(--red);' : 'color:grey;'}"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;

    // Increment the global post counter
    globalPostCounter++;

    // Insert an ad every 10 posts
    if (globalPostCounter % 1 === 0) {
        postHTML += `
            <div class="ad-container" style="width: 100%; display: flex; justify-content: center; margin: 10px 0;">
                <div class="iframe-container" style="width: 300px; height: 250px; border: 1px solid #ccc;">
                    <iframe 
                        src="https://adz1223.blogspot.com/2024/08/download-app.html" 
                        title="AD" 
                        style="width: 100%; height: 100%; border: none;">
                    </iframe>
                </div>
            </div>
        `;
    }

    return postHTML; // Return the complete HTML content
}

    function renderComment(comment) {
        const commentElement = document.createElement('div');
        commentElement.className = 'show-comments';
        commentElement.id = `comment-${comment.id}`;
        commentElement.innerHTML = `
            <div class="comment-user">
                <img src="https://chati.com.ng/i/image/${comment.user_img}" alt="User Image" class="pimg">
                <div>
                    <span onclick="navigateToProfile('${comment.user_name}')">${comment.user_name}</span>
                    <div class="dat">${timeAgo(comment.date)}</div>
                </div>
            </div>
            <div class="comment-box">${comment.comment}</div>
            <div class="comment-actions" id="com">
                ${comment.has_replies ? `<button class="show-replies-btn" data-comment-id="${comment.id}">Show Replies (${comment.reply_count})</button>` : ''}
                <button class="show-reply-form" data-comment-id="${comment.id}">Reply</button>
                ${comment.user_id == userId ? `
                    <button class="edit-comment-btn" data-comment-id="${comment.id}">Edit</button>
                    <button class="delete-comment-btn" data-comment-id="${comment.id}">Delete</button>
                ` : ''}
            </div>
            <div class="replies-container" id="replies-${comment.id}" style="display: none;"></div>
            <form class="add-reply-form" id="reply-form-${comment.id}" style="display: none;">
                <textarea name="reply" maxlength="1000" class="reply-box" cols="30" rows="3" placeholder="Write your reply" required></textarea>
                <button type="submit" class="inline-btn">Add Reply</button>
            </form>
        `;
        
        setupShowRepliesButton(commentElement, comment.id);
        setupReplyForm(commentElement, comment.id);
        setupEditCommentButton(commentElement, comment.id);
        setupDeleteCommentButton(commentElement, comment.id);

        return commentElement;
    }

    function renderReply(reply) {
        const replyElement = document.createElement('div');
        replyElement.className = 'reply';
        replyElement.id = `reply-${reply.id}`;
        replyElement.innerHTML = `
            <div class="reply-user" id="repl">
                <img src="https://chati.com.ng/i/image/${reply.user_img}" alt="User Image" class="pimg">
                <div>
                    <span onclick="navigateToProfile('${reply.user_name}')">${reply.user_name}</span>
                    <div class="dat">${timeAgo(reply.date)}</div>
                </div>
            </div>
            <div class="reply-box">${reply.reply}</div>
        `;

        if (reply.user_id === userId) {
            replyElement.innerHTML += `
                <button class="edit-reply-btn repl" data-reply-id="${reply.id}">Edit</button>
                <button class="delete-reply-btn repl" data-reply-id="${reply.id}">Delete</button>
            `;
        }

        setupEditReplyButton(replyElement, reply.id);
        setupDeleteReplyButton(replyElement, reply.id);

        return replyElement;
    }

    function setupLikeButton(id, type, likes, userLiked) {
        const likeBtn = document.getElementById(`like-${type}-${id}`);
        if (likeBtn) {
            likeBtn.querySelector('i').style.color = userLiked ? 'var(--red)' : 'grey';
            likeBtn.onclick = () => handleLike(id, type);
        }
    }

    function setupCommentForm() {
        const form = document.getElementById('add-comment-form');
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const commentContent = form.querySelector('textarea').value;
            addComment(commentContent);
            form.reset();
        });
    }

    function setupReplyForm(commentElement, commentId) {
        const form = commentElement.querySelector(`#reply-form-${commentId}`);
        const showFormBtn = commentElement.querySelector('.show-reply-form');

        showFormBtn.addEventListener('click', () => {
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const replyContent = form.querySelector('textarea').value;
            addReply(commentId, replyContent);
            form.reset();
            form.style.display = 'none';
        });
    }

    

    function navigateToProfile(username) {
        window.location.href = `u.html?u=${encodeURIComponent(username)}`;
    }

    function addComment(commentContent) {
        fetch('https://chati.com.ng/i/api/view.php?action=add_comment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `post_id=${postId}&comment=${encodeURIComponent(commentContent)}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            location.reload();
        })
        .catch(error => console.error('Error adding comment:', error));
    }

    function updateCommentElement(commentData) {
    const commentElement = document.getElementById(`comment-${commentData.id}`);
    if (commentElement) {
        const userImg = commentElement.querySelector('.pimg');
        const userName = commentElement.querySelector('.comment-user span');
        const dateElement = commentElement.querySelector('.dat');

        if (userImg) userImg.src = `https://chati.com.ng/i/image/${commentData.user_img}`;
        if (userName) userName.textContent = commentData.user_name;
        if (dateElement) dateElement.textContent = timeAgo(commentData.date);

        // Update any other fields as necessary
    }
}

    function addReply(commentId, replyContent) {
        fetch('https://chati.com.ng/i/api/view.php?action=add_reply', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `comment_id=${commentId}&reply=${encodeURIComponent(replyContent)}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            if (data.success) {
                fetchReplies(commentId);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function setupShowRepliesButton(commentElement, commentId) {
        const showRepliesBtn = commentElement.querySelector('.show-replies-btn');
        if (showRepliesBtn) {
            showRepliesBtn.addEventListener('click', () => {
                const repliesContainer = commentElement.querySelector(`#replies-${commentId}`);
                if (repliesContainer.style.display === 'none') {
                    fetchReplies(commentId);
                    repliesContainer.style.display = 'block';
                } else {
                    repliesContainer.style.display = 'none';
                }
            });
        }
    }

    function fetchReplies(commentId) {
        fetch(`https://chati.com.ng/i/api/view.php?action=get_replies&comment_id=${commentId}`, {
            headers: {
                'Authorization': `Bearer ${userId}`
            }
        })
        .then(response => response.json())
        .then(replies => {
            const repliesContainer = document.getElementById(`replies-${commentId}`);
            repliesContainer.innerHTML = '';
            replies.forEach(reply => {
                repliesContainer.appendChild(renderReply(reply));
            });
            repliesContainer.style.display = 'block';
        })
        .catch(error => console.error('Error:', error));
    }

    function setupEditCommentButton(commentElement, commentId) {
        const editBtn = commentElement.querySelector('.edit-comment-btn');
        if (editBtn) {
            editBtn.addEventListener('click', () => {
                const commentBox = commentElement.querySelector('.comment-box');
                if (commentBox.querySelector('textarea')) {
                    return;
                }
                const currentContent = commentBox.textContent;
                commentBox.innerHTML = `
                    <textarea class="ucc">${currentContent}</textarea>
                    <button class="update-comment-btn uc">Update</button>
                    <button class="cancel-edit-btn uc">Cancel</button>
                `;
                setupUpdateCommentButton(commentElement, commentId);
                setupCancelEditButton(commentElement, commentId, currentContent);
            });
        }
    }

    function setupUpdateCommentButton(commentElement, commentId) {
        const updateBtn = commentElement.querySelector('.update-comment-btn');
        updateBtn.addEventListener('click', () => {
            const newContent = commentElement.querySelector('textarea').value;
            updateComment(commentId, newContent);
            const commentBox = commentElement.querySelector('.comment-box');
            commentBox.innerHTML = newContent;
        });
    }

    function setupCancelEditButton(commentElement, commentId, originalContent) {
        const cancelBtn = commentElement.querySelector('.cancel-edit-btn');
        cancelBtn.addEventListener('click', () => {
            commentElement.querySelector('.comment-box').textContent = originalContent;
        });
    }

    function setupDeleteCommentButton(commentElement, commentId) {
        const deleteBtn = commentElement.querySelector('.delete-comment-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to delete this comment?')) {
                    deleteComment(commentId);
                }
            });
        }
    }

    function updateComment(commentId, newContent) {
        fetch('https://chati.com.ng/i/api/view.php?action=update_comment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `comment_id=${commentId}&comment=${encodeURIComponent(newContent)}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            if (data.success) {
                const commentElement = document.getElementById(`comment-${commentId}`);
                const commentBox = commentElement.querySelector('.comment-box');
                commentBox.textContent = newContent;
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function deleteComment(commentId) {
        fetch('https://chati.com.ng/i/api/view.php?action=delete_comment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `comment_id=${commentId}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            if (data.success) {
                const commentElement = document.getElementById(`comment-${commentId}`);
                commentElement.remove();
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function setupEditReplyButton(replyElement, replyId) {
        const editBtn = replyElement.querySelector('.edit-reply-btn');
        if (editBtn) {
            editBtn.addEventListener('click', () => {
                const replyBox = replyElement.querySelector('.reply-box');
                if (replyBox.querySelector('textarea')) {
                    return;
                }
                const currentContent = replyBox.textContent;
                replyBox.innerHTML = `
                    <textarea class="ucc">${currentContent}</textarea>
                    <button class="update-reply-btn uc">Update</button>
                    <button class="cancel-edit-reply-btn uc">Cancel</button>
                `;
                setupUpdateReplyButton(replyElement, replyId);
                setupCancelEditReplyButton(replyElement, replyId, currentContent);
            });
        }
    }

    function setupUpdateReplyButton(replyElement, replyId) {
        const updateBtn = replyElement.querySelector('.update-reply-btn');
        updateBtn.addEventListener('click', () => {
            const newContent = replyElement.querySelector('textarea').value;
            updateReply(replyId, newContent);
        });
    }

    function setupCancelEditReplyButton(replyElement, replyId, originalContent) {
        const cancelBtn = replyElement.querySelector('.cancel-edit-reply-btn');
        cancelBtn.addEventListener('click', () => {
            replyElement.querySelector('.reply-box').textContent = originalContent;
        });
    }

    function setupDeleteReplyButton(replyElement, replyId) {
        const deleteBtn = replyElement.querySelector('.delete-reply-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to delete this reply?')) {
                    deleteReply(replyId);
                }
            });
        }
    }

    function updateReply(replyId, newContent) {
        fetch('https://chati.com.ng/i/api/view.php?action=update_reply', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `reply_id=${replyId}&reply=${encodeURIComponent(newContent)}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            if (data.success) {
                fetchReplies(data.comment_id);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function deleteReply(replyId) {
        fetch('https://chati.com.ng/i/api/view.php?action=delete_reply', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': `Bearer ${userId}`
            },
            body: `reply_id=${replyId}`
        })
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        
            if (data.success) {
                fetchReplies(data.comment_id);
            }
        })
        .catch(error => console.error('Error:', error));
    }
});