import { W as WebPlugin } from "./new-BXpXmiND.js";
class SplashScreenWeb extends WebPlugin {
  async show(_options) {
    return void 0;
  }
  async hide(_options) {
    return void 0;
  }
}
export {
  SplashScreenWeb
};
