let currentPage = 1;
let loading = false;
const postsPerPage = 10;
const postsContainer = document.getElementById('posts-box-container');
const profileInfoContainer = document.getElementById('profile-info');

// Function to get user_id from localStorage
function getUserIdFromLocalStorage() {
    const userIdString = localStorage.getItem('user_id');
    return userIdString ? Number(userIdString) : null;
}

const userId = getUserIdFromLocalStorage();

document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('u');
    
    if (username) {
        loadUserProfile(username);
        loadUserPosts(username);
    } else {
        console.error('No username provided');
    }
});

async function loadUserProfile(username) {
    try {
        const response = await fetch(`https://chati.com.ng/i/api/user_profile.php?username=${encodeURIComponent(username)}&user_id=${userId}`);
        const text = await response.text();
        const data = JSON.parse(text);
        
        if (data.profile) {
            renderProfileInfo(data.profile);
        } else {
            profileInfoContainer.innerHTML = '<p>Profile not found.</p>';
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
    }
}

function renderProfileInfo(profile) {
    const joinedDate = new Date(profile.date).toLocaleString('default', { month: 'long', year: 'numeric' });
    profileInfoContainer.innerHTML = `
        <img src="https://chati.com.ng/i/image/${profile.img}" alt="Profile" class="pimg" id="profile-picture">
        <h1>${profile.name}</h1>
        <p class="username">@${profile.name}</p>
        <p class="additional-info">Joined ${joinedDate}</p>
    `;
}

function loadUserPosts(username) {
    loading = true;
    document.querySelector('.loading').style.display = 'block';

    fetch(`https://chati.com.ng/i/api/user_profile.php?username=${encodeURIComponent(username)}&page=${currentPage}&limit=${postsPerPage}&user_id=${userId}`)
        .then(response => response.text())
        .then(text => {
            return JSON.parse(text);
        })
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.posts && data.posts.length > 0) {
                data.posts.forEach(post => {
                    postsContainer.innerHTML += renderPost(post);
                });
                currentPage++;
                loading = false;
            }
            document.querySelector('.loading').style.display = 'none';
        })
        .catch(error => {
            console.error('Error fetching posts:', error);
            document.querySelector('.loading').style.display = 'none';
        });
}
let globalPostCounter = 0;
// Render the post HTML
function renderPost(post) {
    let postHTML = `
        <div class="box"><br>
            <div class="post-admin">
                <img src="https://chati.com.ng/i/${post.adminImage}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link" onclick="navigateToProfile('${post.adminName}')">${post.adminName}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div>
            <a href="view_post.html?post_id=${post.id}" class="inline-btn" id="co">
                <div class="post-content" id="pco">${post.content}</div>
                ${post.image && post.image !== 'null.jpg' ? 
                    `<img src="https://chati.com.ng/i/uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                    <br>` : ''
                }
            </a>
            <div class="icons" id="icoo">
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <div onclick="reportPost(${post.id})"><i class="fas fa-flag"></i></div>     
                <button type="button" class="like-btn ${post.userLiked ? 'liked' : ''}" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="${post.userLiked ? 'color:var(--red);' : 'color:grey;'}"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;

    // Insert custom iframe ad every 10 posts
    globalPostCounter++; // Increment global post counter
    if (globalPostCounter % 10 === 0) {
        postHTML += `
            <div class="ad-container" style="width: 100%; display: flex; justify-content: center; margin: 10px 0;">
                <style>
                    .iframe-container {
                        width: 300px;
                        height: 250px;
                        border: 1px solid #ccc;
                    }
                    .iframe-container iframe {
                        width: 100%;
                        height: 100%;
                        border: none;
                    }
                </style>
                <div class="iframe-container">
                    <iframe src="https://adz1223.blogspot.com/2024/08/download-app.html" title="AD"></iframe>
                </div>
            </div>
        `;
    }

    return postHTML;
}

// Remove any existing ad-related functions or event listeners
function renderAds() {
    console.log('Simple ad rendering initialized');
}
function navigateToProfile(adminName) {
    window.location.href = `u.html?u=${encodeURIComponent(adminName)}`;
}

// Utility function for time ago



// Implement infinite scroll
window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 800) {
        if (!loading) {
            const urlParams = new URLSearchParams(window.location.search);
            const username = urlParams.get('u');
            if (username) {
                loadUserPosts(username);
            }
        }
    }
});
