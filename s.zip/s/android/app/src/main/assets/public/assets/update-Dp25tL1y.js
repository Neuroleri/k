import "./new-BXpXmiND.js";
/* empty css             */
import {
  C as Camera,
  a as CameraResultType,
  b as CameraSource,
} from "./index-BOQCc4j7.js";
function getUserIdFromLocalStorage() {
  const userIdString = localStorage.getItem("user_id");
  return userIdString ? Number(userIdString) : null;
}
getUserIdFromLocalStorage();
function validateFileType(input) {
  const file = input.files[0];
  const allowedTypes = ["image/jpeg", "image/png"];
  if (file && !allowedTypes.includes(file.type)) {
    Swal.fire({
      icon: "warning",
      title: "Invalid file type",
      text: "Please select a valid image file (JPEG, PNG)",
      confirmButtonText: "Okay",
    });
    input.value = "";
  }
}
function handleFetchError(error) {
  console.error("Fetch error:", error);
  Swal.fire({
    icon: "error",
    title: "Error",
    text: "An error occurred while communicating with the server. Please try again later.",
    confirmButtonText: "Okay",
  });
}
document.addEventListener("DOMContentLoaded", function () {
  const userId = getUserIdFromLocalStorage();
  if (!userId) {
    Swal.fire({
      icon: "warning",
      title: "Login Required",
      text: "You need to log in to update your profile.",
      confirmButtonText: "Login",
    }).then(() => {
      window.location.href = "login.html";
    });
    return;
  }
  fetch(
    `https://chati.com.ng/i/api/update.php?action=get_user&id=${userId}`
  )
    .then((response) => {
      if (!response.ok) throw new Error("Network response was not ok");
      return response.json();
    })
    .then((data) => {
      document.getElementById("spinner").style.display = "none";
      if (data.error) throw new Error(data.error);
      document.getElementById("name").placeholder = data.name;
      document.getElementById("email").value = data.email;
    })
    .catch(handleFetchError);
  document
    .getElementById("updateForm")
    .addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData(this);
      formData.append("user_id", userId);
      fetch("https://chati.com.ng/i/api/update.php?action=update_user", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          if (!response.ok) throw new Error("Network response was not ok");
          return response.json();
        })
        .then((data) => {
          document.getElementById("spinner").style.display = "none";
          if (data.error) throw new Error(data.error);
          Swal.fire({
            icon: "success",
            title: "Profile updated!",
          }).then(() => {
            setTimeout(function () {
              location.reload();
            }, 400);
          });
        })
        .catch(handleFetchError);
    });
  document
    .querySelector('label[for="imagee"]')
    .addEventListener("click", async function (e) {
      e.preventDefault();
      try {
        const image = await Camera.getPhoto({
          quality: 90,
          allowEditing: true,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Photos,
          width: 400,
          height: 400,
          correctOrientation: true,
        });
        const response = await fetch(image.dataUrl);
        const blob = await response.blob();
        const file = new File([blob], "profile.jpg", { type: "image/jpeg" });
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        const imageInput = document.getElementById("imagee");
        imageInput.files = dataTransfer.files;
        const imagePreview = document.getElementById("image-preview");
        imagePreview.innerHTML = "";
        const container = document.createElement("div");
        container.style.position = "relative";
        container.style.display = "inline-block";
        const img = document.createElement("img");
        img.src = image.dataUrl;
        img.style.width = "100px";
        img.style.height = "100px";
        img.style.marginTop = "15px";
        img.style.borderRadius = "50%";
        container.appendChild(img);
        const cancelButton = document.createElement("button");
        cancelButton.innerHTML = "&times;";
        cancelButton.style.position = "absolute";
        cancelButton.style.top = "15px";
        cancelButton.style.right = "0";
        cancelButton.style.background = "red";
        cancelButton.style.color = "white";
        cancelButton.style.border = "none";
        cancelButton.style.borderRadius = "50%";
        cancelButton.style.width = "20px";
        cancelButton.style.height = "20px";
        cancelButton.style.cursor = "pointer";
        cancelButton.addEventListener("click", function () {
          imagePreview.innerHTML = "";
          imageInput.value = "";
        });
        container.appendChild(cancelButton);
        imagePreview.appendChild(container);
      } catch (error) {
        console.error("Error selecting image:", error);
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Failed to select image. Please try again.",
        });
      }
    });
  document.getElementById("imagee").addEventListener("change", function () {
    validateFileType(this);
    const imagePreview = document.getElementById("image-preview");
    imagePreview.innerHTML = "";
    const file = this.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (event) {
        const container = document.createElement("div");
        container.style.position = "relative";
        container.style.display = "inline-block";
        const img = document.createElement("img");
        img.src = event.target.result;
        img.style.width = "100px";
        img.style.height = "100px";
        img.style.marginTop = "15px";
        img.style.borderRadius = "50%";
        container.appendChild(img);
        const cancelButton = document.createElement("button");
        cancelButton.innerHTML = "&times;";
        cancelButton.style.position = "absolute";
        cancelButton.style.top = "15px";
        cancelButton.style.right = "0";
        cancelButton.style.background = "red";
        cancelButton.style.color = "white";
        cancelButton.style.border = "none";
        cancelButton.style.borderRadius = "50%";
        cancelButton.style.width = "20px";
        cancelButton.style.height = "20px";
        cancelButton.style.cursor = "pointer";
        cancelButton.addEventListener("click", function () {
          imagePreview.innerHTML = "";
          document.getElementById("imagee").value = "";
        });
        container.appendChild(cancelButton);
        imagePreview.appendChild(container);
      };
      reader.readAsDataURL(file);
    }
  });
});
document.getElementById("logout-btn").addEventListener("click", function () {
  Swal.fire({
    title: "Are you sure?",
    text: "You will be logged out!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, logout",
    cancelButtonText: "No, stay logged in",
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
  }).then(async (result) => {
    if (result.isConfirmed) {
      localStorage.removeItem("user_id");
      await Swal.fire({
        title: "Logged Out!",
        text: "You have been successfully logged out.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false,
      });
      window.location.href = "login.html";
    }
  });
});
