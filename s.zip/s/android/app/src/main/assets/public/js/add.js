import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

function getUserIdFromLocalStorage() {
    const userIdString = localStorage.getItem('user_id');
    return userIdString ? Number(userIdString) : null;
}

document.getElementById('spinner').style.display = 'none';
document.addEventListener('DOMContentLoaded', async function() {
    const userId = getUserIdFromLocalStorage();

    // Check if user is logged in
    if (!userId) {
        Swal.fire({
            icon: 'warning',
            title: 'User not logged in',
            text: 'Please log in to continue.',
        }).then(() => {
            window.location.href = 'login.html';
        });
        return;
    }

    // Initialize Camera permissions
    const initializeCamera = async () => {
        const permissionStatus = await Camera.checkPermissions();
        if (permissionStatus.photos === 'denied') {
            await Camera.requestPermissions();
        }
    };

    await initializeCamera();

    // Replace file input handler with Capacitor Camera
    document.getElementById('imageBtn').addEventListener('click', async function() {
        try {
            const image = await Camera.getPhoto({
                quality: 90,
                allowEditing: false,
                resultType: CameraResultType.DataUrl,
                source: CameraSource.Photos
            });

            const imagePreview = document.getElementById('image-preview');
            imagePreview.innerHTML = ''; // Clear previous previews

            const container = document.createElement('div');
            container.style.position = 'relative';
            container.style.display = 'inline-block';
            container.style.maxWidth = '100%';

            const img = document.createElement('img');
            img.src = image.dataUrl;
            img.style.maxWidth = '100%';
            img.style.marginTop = '15px';
            img.style.borderRadius = '3px';
            container.appendChild(img);

            const cancelButton = document.createElement('button');
            cancelButton.innerHTML = '&times;';
            cancelButton.style.position = 'absolute';
            cancelButton.style.top = '20px';
            cancelButton.style.right = '5px';
            cancelButton.style.background = 'rgba(255, 0, 0, 0.7)';
            cancelButton.style.color = 'white';
            cancelButton.style.border = 'none';
            cancelButton.style.borderRadius = '50%';
            cancelButton.style.width = '25px';
            cancelButton.style.height = '25px';
            cancelButton.style.cursor = 'pointer';
            cancelButton.style.display = 'flex';
            cancelButton.style.justifyContent = 'center';
            cancelButton.style.alignItems = 'center';
            cancelButton.style.fontSize = '18px';
            cancelButton.style.padding = '0';

            cancelButton.addEventListener('click', function() {
                imagePreview.innerHTML = '';
                window.selectedImage = null;
            });

            container.appendChild(cancelButton);
            imagePreview.appendChild(container);

            // Store the image data
            window.selectedImage = image.dataUrl;

        } catch (error) {
            console.error('Error selecting image:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to select image. Please try again.',
            });
        }
    });

    // Publish button
    document.getElementById('publishBtn').addEventListener('click', function() {
        submitPost('active');
    });

    // Draft button
    document.getElementById('draftBtn').addEventListener('click', function() {
        submitPost('deactive');
    });

    // Modified submit post function to handle Capacitor image
    function submitPost(status) {
        const form = document.getElementById('postForm');
        const formData = new FormData(form);

        formData.append('user_id', userId);
        formData.append('status', status);

        const content = formData.get('content')?.trim();

        // If we have a selected image from Capacitor
        if (window.selectedImage) {
            // Convert base64 to blob
            const imageBlob = dataURLtoBlob(window.selectedImage);
            formData.append('image', imageBlob, 'image.jpg');
        }

        // Check if both content and image are empty
        if (!content && !window.selectedImage) {
            Swal.fire({
                icon: 'warning',
                title: 'Post Not Submitted',
                text: 'You need to say something or attach an image to make a post!',
            });
            return;
        }

        fetch('https://chati.com.ng/i/api/add.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: status === 'active' ? 'Post Published!' : 'Draft Saved!',
                    text: ' ',
                }).then(() => {
                    window.location.href = 'index.html';
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Post Failed',
                    text: data.message || 'Oops! Something went wrong while sharing your post.',
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An error occurred while trying to share your post. Please try again.',
            });
        });
    }

    // Helper function to convert base64 to blob
    function dataURLtoBlob(dataURL) {
        const arr = dataURL.split(',');
        const mime = arr[0].match(/:(.*?);/)[1];
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], { type: mime });
    }
});

