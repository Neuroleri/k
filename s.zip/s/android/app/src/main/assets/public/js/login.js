document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const confirmPasswordField = document.getElementById('confirmPassword');
    let isRegistering = false;

    // Check if user is already logged in
    const userId = localStorage.getItem('user_id');
    if (userId) {
        // Redirect to the home page or dashboard
        window.location.href = 'index.html';
    }

    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (isRegistering && password !== confirmPassword) {
            Swal.fire({
                icon: 'warning',
                title: 'Passwords do not match',
                text: 'Please make sure both passwords match.',
            });
            return;
        }

        try {
            const response = await fetch('https://chati.com.ng/i/api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    email: email,
                    pass: password,
                    cpass: confirmPassword,
                    submit: isRegistering ? 'Register' : 'Login'
                })
            });

            const rawText = await response.text();
            const jsonString = rawText.match(/\{.*?\}/);

            if (jsonString) {
                const result = JSON.parse(jsonString[0]);

                if (result.status === 'success') {
                    // Store the user ID in localStorage
                    localStorage.setItem('user_id', result.user_id);
                    window.location.href = 'index.html';
                } else if (result.status === 'register' && !isRegistering) {
                    // Switch to registration mode if user not found
                    isRegistering = true;
                    confirmPasswordField.style.display = 'block';
                    confirmPasswordField.required = true;
                } else {
                    // Display error messages
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: result.message || 'Login/Registration failed. Please try again.',
                    });
                }
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Unexpected Response',
                    text: 'Unexpected response format from the server.',
                });
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });
     document.getElementById('spinner').style.display = 'none';
});