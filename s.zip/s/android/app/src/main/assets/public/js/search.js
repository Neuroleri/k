let currentPage = 1;
let loading = false;
const postsPerPage = 10; // Number of posts per request
const postsContainer = document.getElementById('posts-box-container');
let searchQuery = '';

function handleSearch(event) {
    event.preventDefault();
    const searchQuery = event.target.querySelector('input[name="search_box"]').value.trim();
    if (searchQuery) {
        window.location.href = `search.html?q=${encodeURIComponent(searchQuery)}`;
    }
}

// Only run search-related code if we're on the search page
if (window.location.pathname.includes('search.html')) {
    const postsContainer = document.getElementById('posts-box-container');
    
    document.addEventListener('DOMContentLoaded', function() {
        // Get search query from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        searchQuery = urlParams.get('q') || '';
        
        if (searchQuery) {
            // Set the search input value
            const searchInput = document.querySelector('input[name="search_box"]');
            if (searchInput) {
                searchInput.value = searchQuery;
            }
            // Perform initial search
            searchPosts();
        }
        
        // Handle mobile search button
        const searchBtn = document.getElementById('search-btn');
        if (searchBtn) {
            searchBtn.addEventListener('click', function() {
                const header = document.querySelector('.header');
                header.classList.toggle('active');
            });
        }
    });

    // Infinite scroll for search results
    window.addEventListener('scroll', function() {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 800) {
            if (!loading && searchQuery) {
                searchPosts();
            }
        }
    });
}
let globalPostCounter = 0; // Initialize global counter for posts

function renderPost(post) {
    let postHTML = `
        <div class="box"><br>
            <div class="post-admin">
                <img src="https://chati.com.ng/i/${post.adminImage}" alt="Admin Image" class="pimg" loading="lazy">
                <div>
                    <span class="profile-link" onclick="navigateToProfile('${post.adminName}')">${post.adminName}</span>
                    <div class="dat">${timeAgo(post.date)}</div>
                </div>
            </div>
            <a href="view_post.html?post_id=${post.id}" class="inline-btn" id="co">
                <div class="post-content" id="pco">${post.content}</div>
                ${post.image && post.image !== 'null.jpg' ? 
                    `<img src="https://chati.com.ng/i/uploaded_img/${post.image}" class="post-image" alt="" width="100%" height="auto" style="display: block; margin: 0 auto;">
                    <br>` : ''
                }
            </a>
            <div class="icons" id="icoo">
                <div><i class="fas fa-comment"></i><span>${post.comments}</span></div>
                <div onclick="copyUrl('${post.id}')"><i class="fas fa-share"></i></div>
                <div class="report-button" onclick="reportPost(${post.id})">
                    <i class="fas fa-flag"></i>
                </div>
                <button type="button" class="like-btn ${post.userLiked ? 'liked' : ''}" onclick="handleLike(${post.id}, this)">
                    <i class="fas fa-heart" style="${post.userLiked ? 'color:var(--red);' : 'color:grey;'}"></i>
                    <span>${post.likes}</span>
                </button>
            </div>
        </div>
    `;

    globalPostCounter++; // Increment post counter

    // Insert an ad after every 10 posts
    if (globalPostCounter % 10 === 0) {
        postHTML += `
            <div class="ad-container" style="width: 100%; display: flex; justify-content: center; margin: 10px 0;">
                <div class="iframe-container" style="width: 300px; height: 250px; border: 1px solid #ccc;">
                    <iframe 
                        src="https://adz1223.blogspot.com/2024/08/download-app.html" 
                        title="Ad"
                        style="width: 100%; height: 100%; border: none;">
                    </iframe>
                </div>
            </div>
        `;
    }

    return postHTML;
}
// Remove any existing ad-related functions or event listeners
function renderAds() {
    console.log('Simple ad rendering initialized');
}



 

function searchPosts() {
    loading = true;
    

    const userId = getUserIdFromLocalStorage(); // Updated to use localStorage
    const url = new URL(`https://chati.com.ng/i/api/search.php`);
    url.searchParams.append('q', searchQuery);
    url.searchParams.append('page', currentPage);
    url.searchParams.append('limit', postsPerPage);
    if (userId) {
        url.searchParams.append('user_id', userId);
    }

    fetch(url)
        .then(response => response.json())
          .then(data => {      // Once API data is successfully loaded, hide the spinner
        document.getElementById('spinner').style.display = 'none';
            if (data.posts.length > 0) {
                data.posts.forEach(post => {
                    postsContainer.innerHTML += renderPost(post);
                });
                currentPage++;
            } else if (currentPage === 1) {
                postsContainer.innerHTML = '<div class="no-results">No posts found matching your search.</div>';
            }
            loading = false;
             
        })
        .catch(error => {
            console.error('Error searching posts:', error);
             
        });
}

// Functions to set and get user ID from localStorage
function getUserIdFromLocalStorage() {
    return localStorage.getItem('user_id'); // Get user_id from localStorage
}

function setUserIdInLocalStorage(userId) {
    localStorage.setItem('user_id', userId); // Set user_id in localStorage
}

function navigateToProfile(adminName) {
    window.location.href = `u.html?u=${encodeURIComponent(adminName)}`;
}
