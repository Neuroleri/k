import { App } from "@capacitor/app";
import { SplashScreen } from '@capacitor/splash-screen';
import { Share } from '@capacitor/share';
import { Browser } from '@capacitor/browser';

async function openInAppBrowser() {
    try {
        await Browser.open({ url: 'https://epulsemart.com.ng' });
        console.log("InAppBrowser opened");
    } catch (error) {
        console.error("Failed to open InAppBrowser:", error);
        // Fallback to regular window.open
        window.open('https://epulsemart.com.ng', '_blank');
    }
}

async function copyUrl(postId) {
    try {
        const url = `https://chati.com.ng/i/view_post.html?post_id=${postId}`;
        const title = 'Campus Archive Post';
        const text = ``;

        await Share.share({
            title: title,
            text: text,
            url: url,
            dialogTitle: 'Share this post'
        });
    } catch (error) {
        console.error("Share failed:", error);
        // Fallback to clipboard
      //  fallbackCopyToClipboard(url);
    }
}

document.addEventListener('backbutton', async (event) => {
  try {
    // Check if we're on the last page
    if (window.location.pathname === '/') {
      // Prompt the user to quit the app
      const result = await Swal.fire({
        title: 'Exit App',
        text: 'Are you sure you want to exit the app?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, exit',
        cancelButtonText: 'Cancel'
      });

      if (result.isConfirmed) {
        // Exit the app
        await App.exitApp();
      } else {
        // Do nothing, stay in the app
        event.detail.register(10, () => {});
      }
    } else {
      // Go back to the previous page
      window.history.back();
    }
  } catch (error) {
    console.error('Error handling back button:', error);
  }
});


// Initialize Capacitor plugins when the DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Add the deep link listener
        App.addListener("appUrlOpen", (event) => {
            try {
                console.log('Deep link received:', event.url);
                const url = new URL(event.url);
                
                if (url.pathname === '/view_post.html') {
                    const postId = url.searchParams.get('post_id');
                    if (postId) {
                        console.log('Redirecting to post:', postId);
                        window.location.href = `view_post.html?post_id=${postId}`;
                    } else {
                        console.warn('No post_id found in deep link');
                    }
                } else {
                    console.log('Unhandled path:', url.pathname);
                }
            } catch (error) {
                console.error('Error handling deep link:', error);
            }
        });

        // Hide splash screen
        await SplashScreen.hide();
        
        // Export functions to window object so they can be called from HTML
        window.openInAppBrowser = openInAppBrowser;
        window.copyUrl = copyUrl;
        
    } catch (error) {
        console.error("Error initializing app:", error);
    }
});

// Export functions for module usage
export {
    openInAppBrowser,
    copyUrl
};